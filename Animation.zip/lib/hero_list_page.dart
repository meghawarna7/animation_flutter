import 'package:flutter/material.dart';
import 'second_page.dart';

class HeroListPage extends StatelessWidget {
  const HeroListPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("නැරඹීමට සුදුසු ස්ථාන")),
      body: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 500),
          child: ListView.builder(
            itemCount: _images.length,
            itemBuilder: (BuildContext context, int index) {
              return InkWell(
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => SecondPage(
                            heroTag: index,
                            imageUrl: _images[index],
                            title: _titles[index],
                            description: _descriptions[index],
                          )));
                },
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Hero(
                        tag: index,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            _images[index],
                            width: 200,
                            loadingBuilder: (BuildContext context, Widget child,
                                ImageChunkEvent? loadingProgress) {
                              if (loadingProgress == null) return child;
                              return Center(
                                child: CircularProgressIndicator(
                                  value: loadingProgress.expectedTotalBytes !=
                                          null
                                      ? loadingProgress.cumulativeBytesLoaded /
                                          loadingProgress.expectedTotalBytes!
                                      : null,
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                          child: Text(
                        _titles[index],
                        style: Theme.of(context).textTheme.headline6,
                      )),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

final List<String> _images = [
  'https://images.pexels.com/photos/167699/pexels-photo-167699.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
  'https://images.pexels.com/photos/2662116/pexels-photo-2662116.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
  'https://images.pexels.com/photos/273935/pexels-photo-273935.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
  'https://images.pexels.com/photos/1591373/pexels-photo-1591373.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
  'https://images.pexels.com/photos/9013701/pexels-photo-9013701.jpeg?auto=compress&cs=tinysrgb&w=600?auto=compress&cs=tinysrgb&dpr=1&w=500',
  'https://as1.ftcdn.net/v2/jpg/03/64/95/12/1000_F_364951258_xLzCW41kr5AV7OXdVv49ufv6u0XL3nqq.jpg?auto=compress&cs=tinysrgb&dpr=1&w=500'
];

final List<String> _descriptions = [
  ' ඉතාමත් ලස්සන කන්දකි. කඳු යනු සාමාන්‍යයෙන් ප්‍රපාතාකාර බෑවුම් සහ උස් කඳු සහිත අවට පරිසරයට ඉහළින් ඉහළට නැඟී ඇති විශාල භූමි ආකෘති වේ. ඒවා සෑදී ඇත්තේ භූ තැටි චලනය, ගිනිකඳු ක්‍රියාකාරකම් සහ ඛාදනය වැනි භූ විද්‍යාත්මක ක්‍රියාවලීන් මගිනි.',
  '  හරිම ලස්සන ගඟක්.ගංගා: ගංගා යනු ඉහළ උන්නතාංශවල සිට පහළ උන්නතාංශ දක්වා සාමාන්‍යයෙන් සාගරයක්, මුහුදක් හෝ වෙනත් ගංගාවක් දෙසට ගලා යන ස්වභාවික ජල මාර්ග වේ. ඒවා සෑදී ඇත්තේ වර්ෂාපතනයෙන්,',
  'විශාල කාන්තාරයක්. කාන්තාර යනු අවම වර්ෂාපතනය සහ විරල වෘක්ෂලතා වලින් සංලක්ෂිත ශුෂ්ක භූ දර්ශන වේ. ඒවා පෘථිවි පෘෂ්ඨයෙන් තුනෙන් එකක් පමණ ආවරණය වන අතර සෑම මහද්වීපයකම දක්නට ලැබේ.',
  ' වෙරළක් යනු සාමාන්‍යයෙන් වැලි හෝ ගල් කැට වලින් සමන්විත වන අතර බොහෝ විට වෘක්ෂලතා හෝ ව්‍යුහයන්ගෙන් මායිම් වූ ජල කඳක් සමඟ ඇති භූමි ආකෘතියකි. මුහුදු වෙරළ යනු රළ, වඩදිය, සුළඟ සහ ධාරා වල ක්‍රියාකාරිත්වය මගින් හැඩගැසුණු ගතික පරිසරයකි',
  '"සීගිරිය" යනු ශ්‍රී ලංකාවේ මධ්‍යම මාතලේ දිස්ත්‍රික්කයේ පිහිටි ඉපැරණි ගල් බලකොටුවකි. එය සිංහ පර්වතය ලෙසද හඳුන්වනු ලබන්නේ පර්වතය මුදුනේ පිහිටි මාලිගාවට පිවිසෙන දොරටුවේ සිංහ හැඩැති දැවැන්ත දොරටුව නිසාය. ',
  '"දළදා මාලිගාව" යන්නෙන් අදහස් කරන්නේ ශ්‍රී ලංකාවේ මහනුවර නගරයේ පිහිටි බෞද්ධ විහාරස්ථානයක් වන ශ්‍රී දළදා මාලිගාව ය. එය ලොව පුරා වෙසෙන බෞද්ධයන් සඳහා වඩාත් පූජනීය සිද්ධස්ථානයකි.'
];
final List<String> _titles = [
  'මීදුම් සහිත කන්දක්',
  'ලස්සන ගඟක්  ',
  ' කාන්තාරයක්',
  'මුහුදු වෙරළක්',
  ' සීගිරිය ',
  ' දළදා මාලිගාව'
];
